=== Hlídač Státu ===
Contributors: hlidacstatu
Tags: widget,hlidacstatu,hlidacsmluv
Donate link: https://www.darujme.cz/projekt/1200384
Requires at least: 4.0
Tested up to: 5.0.3
Requires PHP: 7.0
License: GPL-v3
License URI: https://github.com/HlidacStatu/Wordpress-plugin/blob/master/LICENSE

Plugin a shortcode pro snadné a spolehlivé vkládání widgetů Hlídače státu do textu.